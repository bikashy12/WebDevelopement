export default [
  {
    title: 'Plan Toys Baby Car',
    image: 'https://images.viglink.com/product/250x250/c1-neweggimages-com/68b1e65f56cfa48418d077570e5c8c4b5ced85a3.jpg?url=https%3A%2F%2Fc1.neweggimages.com%2FNeweggImage%2Fproductimage%2FA0TK_13038_129714870967925225YuilYyEYwx.jpg',
    price: '$14.14',
    horizontal: true,
  },
  {
    title: 'Baby Toys Stickers - Sandylion',
    image: 'https://images.viglink.com/product/250x250/sbing-com/d9dc3ba7f12a356605ca8bc4bd41d4d023f20edc.jpg?url=https%3A%2F%2Fsbing.com%2Fi%2Fproducts%2F0000%2F081%2F81360-o-1.jpg',
    price: '$1.58',
  },
  {
    title: 'Organic Baby Toys Gift Set - Taxi & MetroCard Rattles',
    image: 'https://images.viglink.com/product/250x250/cdn-shopify-com/5c39bf88067061ee94f4d2cd10935299b0afe30c.jpg?url=https%3A%2F%2Fcdn.shopify.com%2Fs%2Ffiles%2F1%2F1278%2F1845%2Fproducts%2Fnyc_taxi_metro_a949a1bd-5b87-4e31-9018-14ca720667c6.jpg',
    price: '$29.95',
  },
  {
    title: 'Baby Toys Baby Personalized Photo Cube',
    image: 'https://images.viglink.com/product/250x250/www-giftsforyounow-com/7b4e87583079a20124c79194c14c14dd574e278f.jpg?url=https%3A%2F%2Fwww.giftsforyounow.com%2F%2Fimages%2Fproducts%2F422554-M.jpg',
    price:'$30.99',
    horizontal: true,
  },
  {
    title: "Men's Modern Leather Loafer Men's Shoes",
    image: 'https://images.viglink.com/product/250x250/slimages-macysassets-com/771392fdf52f123afa44bee8c53b7bd7a6300f8b.jpg?url=https%3A%2F%2Fslimages.macysassets.com%2Fis%2Fimage%2FMCY%2Fproducts%2F4%2Foptimized%2F14728264_fpx.tif%3Fwid%3D300%26fmt%3Djpeg%26qlt%3D100',
    price:'$79.00',
  },
];
