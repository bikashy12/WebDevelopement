export default {
  base_api: 'https://core-api.govava.com/',
  api: 'https://core-api.govava.com/',
  test_api: 'https://core-api.govava.com/',
  // base_api: 'https://7oao5vmhte.execute-api.us-east-1.amazonaws.com/',
  // api: 'https://7oao5vmhte.execute-api.us-east-1.amazonaws.com/',
  // test_api:'https://7oao5vmhte.execute-api.us-east-1.amazonaws.com/',
  // base_api: 'https://m2a0cte3f6.execute-api.us-east-1.amazonaws.com/',
  // api: 'https://m2a0cte3f6.execute-api.us-east-1.amazonaws.com/',
};
