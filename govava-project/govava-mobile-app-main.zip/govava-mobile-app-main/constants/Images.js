const Onboarding =
  'https://images.unsplash.com/photo-1505995433366-e12047f3f144?fit=crop&w=840&q=80';
const Pro =
  'https://images.unsplash.com/photo-1485796826113-174aa68fd81b?fit=crop&w=840&q=80';
const Products = {
  Accessories: 'https://source.unsplash.com//l1MCA0VyNrk/840x840',
};
const offer = require('../assets/images/offer.png');
const offer2 = require('../assets/images/offer2.png');
const m_logo = require('../assets/images/m_logo.jpeg');
const google = require('../assets/images/google.png');
// const Profile =  'https://images.unsplash.com/photo-1512529920731-e8abaea917a5?fit=crop&w=840&q=80';
// const Profile =  'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80';
const Profile =
  'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/The_cricket_legend_Sachin_Tendulkar_at_the_Oval_Maidan_in_Mumbai_During_the_Duke_and_Duchess_of_Cambridge_Visit%2826271019082%29.jpg/260px-The_cricket_legend_Sachin_Tendulkar_at_the_Oval_Maidan_in_Mumbai_During_the_Duke_and_Duchess_of_Cambridge_Visit%2826271019082%29.jpg';
const Avatar =
  'https://images.unsplash.com/photo-1518725522904-4b3939358342?fit=crop&w=210&q=80';

const Viewed = [
  'https://medlineplus.gov/images/Medicines.jpg',
  'https://medlineplus.gov/images/Medicines.jpg',
  'https://medlineplus.gov/images/Medicines.jpg',
  'https://medlineplus.gov/images/Medicines.jpg',
  'https://medlineplus.gov/images/Medicines.jpg',
  'https://medlineplus.gov/images/Medicines.jpg',
];

export default {
  Onboarding,
  Pro,
  Products,
  Profile,
  Viewed,
  Avatar,
  offer,
  offer2,
  m_logo,
  google
};
