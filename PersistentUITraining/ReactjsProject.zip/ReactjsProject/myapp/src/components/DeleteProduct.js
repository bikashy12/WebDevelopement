import React, { useRef } from "react";
import axios from "axios";

export default function DeleteProduct() {
  const deleteRef = useRef(null);
  async function handleDelete() {
    try {
      const responseData = await axios.delete(
        `http://localhost:3000/api/products/${deleteRef.current.value}`
      );
      console.log(responseData);
    } catch (error) {
      console.log(error);
    }
  }
  return (
    <div>
      <label>Remove product with ID </label>&nbsp;
      <input type="text" ref={deleteRef}></input>&nbsp;
      <button type="button" onClick={handleDelete}>
        Delete
      </button>
    </div>
  );
}
