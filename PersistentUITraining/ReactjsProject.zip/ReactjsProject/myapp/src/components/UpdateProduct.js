import React, { useRef, useState } from "react";
import axios from "axios";
import CloseIcon from "@mui/icons-material/Close";

export default function UpdateProduct({ productId, setEditClicked }) {
  const [updatedProduct, setUpdatedProduct] = useState({});
  const [productAdded, setProductAdded] = useState(false);
  const updateRef = useRef(null);
  async function handleUpdate(event) {
    event.preventDefault();
    const header = {
      "Content-Type": "application/json",
    };
    try {
      const responseData = await axios.put(
        `http://localhost:3000/api/products/${updateRef.current[0].value}`,
        updatedProduct,
        { header }
      );
      console.log(responseData);
      setProductAdded(true);
      updateRef.current.reset();
    } catch (error) {
      console.log(error.message);
    }
  }
  function handleFieldChange(event) {
    const fieldToUpdate = event.target.name;
    const valueToPut = event.target.value;
    if (valueToPut === "") {
      setUpdatedProduct((current) => {
        if (fieldToUpdate === "productname") {
          const { productname, ...rest } = current;
          return rest;
        } else if (fieldToUpdate === "modelyear") {
          const { modelyear, ...rest } = current;
          return rest;
        } else if (fieldToUpdate === "price") {
          const { price, ...rest } = current;
          return rest;
        } else if (fieldToUpdate === "description") {
          const { description, ...rest } = current;
          return rest;
        }
      });
      return;
    }
    switch (fieldToUpdate) {
      case "productname":
        setUpdatedProduct({ ...updatedProduct, productname: valueToPut });
        break;
      case "modelyear":
        setUpdatedProduct({ ...updatedProduct, modelyear: valueToPut });
        break;
      case "price":
        setUpdatedProduct({ ...updatedProduct, price: valueToPut });
        break;
      case "description":
        setUpdatedProduct({ ...updatedProduct, description: valueToPut });
        break;
      default:
        break;
    }
  }
  return (
    <>
      <button
        onClick={() => {
          setEditClicked(false);
        }}
        style={{
          transform: "scale(1.3)",
          "margin-left": "5px",
          cursor: "pointer",
        }}
      >
        &lt;
      </button>
      <div className="form">
        <p className="addFormHeading">Update Product Details</p>
        <form ref={updateRef} onSubmit={handleUpdate} className="updateForm">
          <label>Product ID </label>&nbsp;
          <input type="text" value={productId}></input>
          <br></br>
          <label htmlFor="productname">Product Name</label>
          <input
            type="text"
            name="productname"
            onChange={handleFieldChange}
          ></input>
          <br></br>
          <label htmlFor="modelyear">Model Year</label>
          <input
            type="text"
            name="modelyear"
            onChange={handleFieldChange}
          ></input>
          <br></br>
          <label htmlFor="price">Price</label>
          <br></br>
          <input type="text" name="price" onChange={handleFieldChange}></input>
          <br></br>
          <label htmlFor="description">Description</label>
          <input
            type="text"
            name="description"
            onChange={handleFieldChange}
          ></input>
          <br></br>
          <button type="submit" className="welcome-button">
            Update
          </button>
        </form>
      </div>
      {productAdded && (
        <div
          className="overlay add-back"
          onClick={() => {
            setProductAdded(false);
          }}
        ></div>
      )}
      {productAdded && (
        <div className="delete-popup add-popup">
          <p>Great! Product Updated successfully</p>
          <CloseIcon
            className="cross-icon"
            onClick={() => setProductAdded(false)}
          />
        </div>
      )}
    </>
  );
}
