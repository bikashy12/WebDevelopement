import React from "react";
import { useNavigate } from "react-router-dom";

export default function ProductDetails({ product, setProductNameClicked }) {
  const navigate = useNavigate();
  return (
    <div>
      <button
        onClick={() => {
          setProductNameClicked(false);
        }}
        style={{
          transform: "scale(1.3)",
          "margin-left": "5px",
          cursor: "pointer",
        }}
      >
        &lt;
      </button>
      <div className="product-details">
        <div className="detail">
          <table className="detail-table">
            <tr>
              <th>Product Name</th>
              <td>{product.productname}</td>
            </tr>
            <tr>
              <th>Model Year</th>
              <td>{product.modelyear}</td>
            </tr>
            <tr>
              <th>Price </th>
              <td>&#8377;{product.price}</td>
            </tr>
            <tr>
              <th>Description</th>
              <td>{product.description}</td>
            </tr>
          </table>
        </div>
        <div className="text">
          <p>All Information related to the product</p>
        </div>
      </div>
    </div>
  );
}
