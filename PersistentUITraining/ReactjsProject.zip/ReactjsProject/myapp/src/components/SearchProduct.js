import React, { useRef, useState, useEffect } from "react";
import SearchIcon from "@mui/icons-material/Search";
import axios from "axios";
import Footer from "./Footer";
import FilterProduct from "./FilterProduct";
import FilterAltIcon from "@mui/icons-material/FilterAlt";

export default function SearchProduct() {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [filtered, setFiltered] = useState(false);
  const [filterClicked, setFilterClicked] = useState(false);
  const [productChanged, setProductChanged] = useState(false);
  const inputRef = useRef(null);
  const selectRef = useRef(null);
  const fetchProducts = async () => {
    try {
      var allProducts = await axios.get("http://localhost:3000/api/products");
      setProducts(allProducts.data);
    } catch (error) {
      console.log(error);
    } finally {
      setProducts(allProducts.data);
    }
  };
  useEffect(() => {
    fetchProducts();
  }, []);

  // async function handleSearchWithId() {
  //   try {
  //     var product = await axios.get(
  //       `http://localhost:3000/api/products/${inputRef.current.value}`
  //     );
  //     console.log(product.data);
  //     if (product !== undefined) setProducts(product.data);
  //   } catch (error) {
  //     console.log(error.response.data);
  //   }
  // }
  function handleSearchWithId() {
    var newProductList = [];
    newProductList = products.filter((item, index) => {
      console.log(inputRef.current.value);
      if (item.productid === Number(inputRef.current.value)) return item;
    });
    setFilteredProducts(newProductList);
    console.log(filteredProducts);
  }
  function handleSearchWithModelYear() {
    var newProductList = [];
    newProductList = products.filter((item, index) => {
      if (item.modelyear === Number(inputRef.current.value)) return item;
    });
    setFilteredProducts(newProductList);
    console.log(filteredProducts);
  }
  function handleSearchWithName() {
    var newProductList = [];
    newProductList = products.filter((item, index) => {
      if (
        item.productname.toUpperCase() === inputRef.current.value.toUpperCase()
      )
        return item;
    });
    setFilteredProducts(newProductList);
    console.log(filteredProducts);
  }
  function handleSearch() {
    var toSearch = selectRef.current.value;
    switch (toSearch) {
      case "Product Name":
        handleSearchWithName();
        return;
      case "Product ID":
        handleSearchWithId();
        return;
      case "Model Year":
        handleSearchWithModelYear();
        return;
      case "Show All":
        setFilteredProducts(products);
        return;
      default:
        break;
    }
  }
  function handleKeyDown(event) {
    if (event.key === "Enter") {
      setFiltered(true);
      handleSearch();
    }
  }
  return (
    <div>
      <div className="form search-form">
        <button onClick={handleSearch} className="search-btn">
          <SearchIcon
            className="search-icon search-btn"
            onClick={() => {
              setFiltered(true);
              handleSearch();
            }}
          />
        </button>
        <input
          type="text"
          ref={inputRef}
          placeholder="Search products..."
          onKeyDown={handleKeyDown}
        ></input>
        <button className="search-btn filter-icon">
          <FilterAltIcon
            className="search-icon filter-icon"
            onClick={() => {
              setFilterClicked(!filterClicked);
            }}
          />
        </button>
        <select ref={selectRef} className="filter-select">
          <option className="option">Product Name</option>
          <option>Product ID</option>
          <option>Model Year</option>
          <option selected>Show All</option>
        </select>
        <br></br>
      </div>
      {filtered && (
        <FilterProduct
          productList={filteredProducts}
          setProductChanged={setProductChanged}
        />
      )}
      {filteredProducts.size === 0 && <h1>Record Not found!!</h1>}
      <Footer />
    </div>
  );
}
