import React from "react";

export default function Footer() {
  return (
    <div className="header footer">
      <p>&#169; 2023 Copyright pms. All rights reserved.</p>
    </div>
  );
}
