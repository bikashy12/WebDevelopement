import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import AddProduct from "./AddProduct";
import SearchProduct from "./SearchProduct";
import UpdateProduct from "./UpdateProduct";
import DeleteProduct from "./DeleteProduct";
import Navbar from "./Navbar";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import Footer from "./Footer";
import ProductList from "./ProductList";
import { Routes, Route, Link } from "react-router-dom";

export default function Home() {
  return (
    <div>
      <header className="header">
        <h1>Product Management System</h1>
        <p>
          Revolutionize Your Product Management with Our Streamlined System:
          Simplify Inventory and Boost Sales with Ease
        </p>
        <button type="button" className="welcome-button">
          <a href="#showProducts">
            <span>Get Started</span>
          </a>
          <ArrowForwardIcon className="arrow-icon" />
        </button>
      </header>
      <div className="showProducts" id="showProducts">
        <div className="showProductText">Get all the products in Inventory</div>
        <div className="showProductBtn">
          <button className="welcome-button">
            <Link to="/products" className="link">
              <span id="btnStyle">Show all Product</span>
            </Link>
          </button>
        </div>
      </div>
      <div className="addProducts">
        <div className="addProductText">
          Great! Adding a product is quick and easy.
        </div>
        <div className="addProductBtn">
          <button className="welcome-button">
            <Link to="/addproduct" className="link">
              <span>Add New Product</span>
            </Link>
          </button>
        </div>
      </div>
      <div className="showProducts" id="showProducts">
        <div className="showProductText">
          Filter your product quickly and easily from the Inventory
        </div>
        <div className="showProductBtn">
          <Link to="/search" className="link">
            <button className="welcome-button">
              <span id="btnStyle">Ready to filter ?</span>
            </button>
          </Link>
        </div>
      </div>
      <div id="about">
        <Footer />
      </div>
    </div>
  );
}
