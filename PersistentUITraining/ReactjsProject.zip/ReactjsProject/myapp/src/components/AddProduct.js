import React, { useRef, useState } from "react";
import axios from "axios";
import Footer from "./Footer";
import CloseIcon from "@mui/icons-material/Close";

export default function AddProduct() {
  const [productAdded, setProductAdded] = useState(false);
  const formRef = useRef(null);
  async function handleSubmit(event) {
    event.preventDefault();
    const [productid, productname, modelyear, price, description] =
      formRef.current;
    const newProduct = {
      productid: productid.value,
      productname: productname.value,
      modelyear: modelyear.value,
      price: price.value,
      description: description.value,
    };
    try {
      const header = {
        "Content-Type": "application/json",
      };
      const response = await axios.post(
        "http://localhost:3000/api/products",
        newProduct,
        { header }
      );
      console.log(response);
      setProductAdded(true);
    } catch (error) {
      console.log(error);
    } finally {
      formRef.current.reset();
    }
    console.log(newProduct);
  }
  return (
    <div>
      <div className="form add-form">
        <div>
          <p className="addFormHeading">Create New Product</p>
          <form ref={formRef} onSubmit={handleSubmit}>
            <label>Product Id </label>
            <input type="text" required></input>
            <br></br>
            <label>Product Name</label>
            <input type="text" required></input>
            <br></br>
            <label>Model Year</label>
            <input type="text" required></input>
            <br></br>
            <label>Price</label>
            <br></br>
            <input type="text" required></input>
            <br></br>
            <label>Description</label>
            <input type="text" required></input>
            <br></br>
            <button type="submit" className="welcome-button">
              Add
            </button>
          </form>
        </div>
        {productAdded && (
          <div
            className="overlay add-back"
            onClick={() => {
              setProductAdded(false);
            }}
          ></div>
        )}
        {productAdded && (
          <div className="delete-popup add-popup">
            <p>Hurrah! Product Added successfully</p>
            <CloseIcon
              className="cross-icon"
              onClick={() => setProductAdded(false)}
            />
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
