import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import Home from "./Home";
import ProductList from "./ProductList";
import Footer from "./Footer";
import ProductDetails from "./ProductDetails";
import SearchProduct from "./SearchProduct";
import AddProduct from "./AddProduct";

export default function Navbar() {
  return (
    <>
      <ul className="navbar">
        <li>
          <Link className="link" to="/home">
            Home
          </Link>
        </li>
        <li>
          <Link className="link" to="/products">
            Products
          </Link>
        </li>
        <li>
          <a className="link" href="#about">
            About
          </a>
        </li>
      </ul>
      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/home" element={<Home />}></Route>
        <Route path="/products" element={<ProductList />}></Route>
        <Route path="/search" element={<SearchProduct />}></Route>
        <Route path="/addproduct" element={<AddProduct />}></Route>
      </Routes>
    </>
  );
}
