import React, { useState, useRef, useEffect } from "react";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import ProductDetails from "./ProductDetails";
import UpdateProduct from "./UpdateProduct";
import axios from "axios";

export default function FilterProduct({ productList }) {
  const [productNameClicked, setProductNameClicked] = useState(false);
  const [displayProduct, setDisplayProduct] = useState({});
  const [editClicked, setEditClicked] = useState(false);
  const [products, setProducts] = useState([]);
  const [deleted, setDeleted] = useState(false);
  const [deletePrompt, setDeletePrompt] = useState(false);
  const [filteredProduct, setFilteredProduct] = useState(productList);
  const [toDelete, setToDelete] = useState(null);
  const popupRef = useRef(null);

  const fetchProducts = async () => {
    try {
      var allProducts = await axios.get("http://localhost:3000/api/products");
      setProducts(allProducts.data);
    } catch (error) {
      console.log(error);
    } finally {
      setProducts(allProducts.data);
    }
  };
  useEffect(() => {
    fetchProducts();
  }, []);
  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (popupRef.current && !popupRef.current.contains(event.target)) {
        if (deletePrompt) {
          setDeletePrompt(false);
        }
      }
    };
    document.addEventListener("mousedown", handleOutsideClick);
    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, [deletePrompt]);
  async function handleDelete(productId) {
    try {
      const responseData = await axios.delete(
        `http://localhost:3000/api/products/${productId}`
      );
      setDeleted(true);
      setProducts(() => {
        return products.filter((item) => {
          return item.productid !== productId && item;
        });
      });
      productList = products;
      setDeleted(true);
      console.log(responseData);
    } catch (error) {
      console.log(error);
    }
  }
  if (productList.length === 0)
    return (
      <div>
        <h2 className="notFound">Record Not found!!</h2>
      </div>
    );
  return (
    <div>
      {!productNameClicked && !editClicked && (
        <table className="table  filter-table">
          <th>SNo</th>
          <th>ID</th>
          <th>Name</th>
          <th>Price(&#8377;)</th>
          <th>Model Year</th>
          <th>Edit</th>
          <th>Delete</th>
          {productList.map((item, index) => {
            return (
              <tr key={item.productid}>
                <td>{index + 1}</td>
                <td>{item.productid}</td>
                <td
                  onClick={() => {
                    setDisplayProduct(item);
                    setProductNameClicked(true);
                  }}
                  className="product-name"
                >
                  <span>{item.productname}</span>
                </td>
                <td>{item.price}</td>
                <td>{item.modelyear}</td>
                <td
                  onClick={() => {
                    setEditClicked(true);
                    setDisplayProduct(item);
                  }}
                >
                  <EditIcon className="showProductIcon" />
                </td>
                <td
                  onClick={() => {
                    setDeletePrompt(true);
                    setToDelete(item.productid);
                  }}
                >
                  <DeleteIcon className="showProductIcon deleteIcon" />
                </td>
              </tr>
            );
          })}
        </table>
      )}
      {deletePrompt && (
        <div
          className="overlay"
          onClick={() => {
            setDeletePrompt(!deletePrompt);
          }}
        ></div>
      )}
      {deletePrompt && (
        <div className="delete-container" ref={popupRef}>
          <div className="delete-popup">
            <p>Are you sure you want to delete this item?</p>
            <div className="popup-button">
              <button
                onClick={() => setDeletePrompt(false)}
                type="button"
                id="cancel"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  handleDelete(toDelete);
                  setDeletePrompt(false);
                }}
                id="delete"
                type="button"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
      {editClicked && (
        <UpdateProduct
          productId={displayProduct.productid}
          setEditClicked={setEditClicked}
        />
      )}
      {productNameClicked && (
        <ProductDetails
          product={displayProduct}
          setProductNameClicked={setProductNameClicked}
        />
      )}
    </div>
  );
}
